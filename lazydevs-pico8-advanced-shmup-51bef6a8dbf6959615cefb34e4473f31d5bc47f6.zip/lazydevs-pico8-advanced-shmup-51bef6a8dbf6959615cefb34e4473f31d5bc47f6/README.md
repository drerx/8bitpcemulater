# Pico-8 Advanced Shmup Tutorial

This is a repository of the Lazy Devs Academy Pico-8 Hero Advanced Shmup Tutorial. 

The corresponding video series is available here:
https://www.youtube.com/playlist?list=PLea8cjCua_P1o-xiQRf_QzqS2pMVlGnse

Join the discussion on the Discord server: 
https://discordapp.com/invite/N9NBX8R

WARNING: If you are using this repository to download the state of the project at a specific point in the tutorial make sure to use GitHub's History feature.
